import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  static final _firestore = FirebaseFirestore.instance;

  static Future<void> addReport(String text) async {
    await _firestore.collection('reports').add({
      'text': text,
      'createdAt': DateTime.now(),
    });
  }
}
