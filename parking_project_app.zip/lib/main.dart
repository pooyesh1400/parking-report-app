import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ParkingApp());
}

class ParkingApp extends StatelessWidget {
  const ParkingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'پروژه پارکینگ',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        fontFamily: 'iranSans',
      ),
      home: const HomeScreen(),
    );
  }
}
