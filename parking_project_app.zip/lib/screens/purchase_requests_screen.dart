import 'package:flutter/material.dart';

class PurchaseRequestsScreen extends StatelessWidget {
  const PurchaseRequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('درخواست‌های خرید')),
      body: const Center(
        child: Text('در این بخش درخواست‌های خرید نمایش داده می‌شوند.'),
      ),
    );
  }
}
