document.getElementById('reportForm').addEventListener('submit', function(e){
  e.preventDefault();
  const date = document.getElementById('date').value;
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  if(date && title && description){
    const reports = JSON.parse(localStorage.getItem('reports') || '[]');
    reports.push({ date, title, description });
    localStorage.setItem('reports', JSON.stringify(reports));
    showReports();
    this.reset();
  }
});
function showReports(){
  const reportList = document.getElementById('reportList');
  reportList.innerHTML = '';
  const reports = JSON.parse(localStorage.getItem('reports') || '[]');
  reports.forEach((r, index) => {
    const li = document.createElement('li');
    li.innerHTML = `<span><strong>${r.date}</strong> - ${r.title}<br>${r.description}</span>
      <button class="delete-btn" onclick="deleteReport(${index})">حذف</button>`;
    reportList.appendChild(li);
  });
}
function deleteReport(index){
  const reports = JSON.parse(localStorage.getItem('reports') || '[]');
  reports.splice(index, 1);
  localStorage.setItem('reports', JSON.stringify(reports));
  showReports();
}
document.getElementById('search').addEventListener('input', function(){
  const q = this.value.toLowerCase();
  const items = document.querySelectorAll('#reportList li');
  items.forEach(item => {
    if(item.innerText.toLowerCase().includes(q)){
      item.style.display = 'flex';
    } else {
      item.style.display = 'none';
    }
  });
});
showReports();